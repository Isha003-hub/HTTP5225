
<?php $__env->startSection('content'); ?>
<h1>All students</h1>
<ul>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($student -> fname); ?> <?php echo e($student -> lname); ?> |
            <a href="<?php echo e(route('students.edit', $student -> id )); ?>">Edit</a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\HTTP5225\laralms\resources\views/students/index.blade.php ENDPATH**/ ?>