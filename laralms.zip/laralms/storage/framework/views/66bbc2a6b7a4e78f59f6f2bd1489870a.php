
<?php $__env->startSection('content'); ?>
<h1>Add Student</h1>
    <?php if($errors -> any()): ?>
        <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <form action="<?php echo e(route('students.store')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="text" name="fname" placeholder="fname" value="<?php echo e(old('fname')); ?>">
        <input type="text" name="lname" placeholder="lname">
        <input type="email" name="email" placeholder="email">
        <input type="submit" value="Create">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\HTTP5225\laralms\resources\views/students/create.blade.php ENDPATH**/ ?>