<footer class="py-4 bg-dark">
    <div class="container text-center" style="max-width: 1200px; margin: auto;">
        <p class="mb-1 text-light p-3">&copy; 2025 ReviewMyDrama. All rights reserved.</p>
    </div>
</footer>