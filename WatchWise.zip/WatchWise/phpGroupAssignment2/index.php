<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WatchWise</title>

    <!-- Stylesheet -->
    <link rel="stylesheet" href="./styles/styles.css">
</head>
<body>
    <main>
        <?php
            include("reusables/connection.php");
        ?>

        <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">WatchWise</a>
            <div class="d-flex">
            <!-- <a href="login.php" class="nav-link">Admin Login</a> -->
            </div>
        </div>

        <div class="row">
                <?php  
                    $query = "SELECT * FROM movies";
                    $movies = mysqli_query($connect, $query);
                
                    foreach($movies as $movie)
                    {
                        echo '   
                            <div class="col-md-4">
                                <div class="card  drama-card mb-4">
                                    <img src= "posters/'. $movie['poster_url'] .'" class="card-img-top" alt="'. $movie['title'].'">
                                
                                    <div class="card-body">
                                    <h5 class="card-title">'.$movie['title'].' <span class="badge">'.$movie['rating'].' </span></h5> 
                                    <h6 class="card-subtitle mb-2 text-muted">'.$movie['release_year'].'</h6>
                                    <h6 class="card-subtitle mb-2">Network: '.$movie['network'].'</h6>
                                    <p class="card-text">'.$movie['description'].'</p>
                                    <p class="card-text cast" >Cast: '.$movie['cast'].'</p> 
                                    <form action="reviews.php" method="GET"> 
                                        <input type="hidden" name="drama_id" value="'.$movie['id'].'">
                                        <button type="submit" class="btn btn-submit">Reviews</button>
                                    </form>
                                    </div>

                                </div> 
                            </div>
                        ';
                    }        
                ?>
            </div>
        </nav>
    </main>

    <a href="http://localhost/HTTP5225/week8/admin">Login</a>

    <?php
        include("reusables/header.php"); 
    ?>
    
    <?php
        include("reusables/footer.php"); 
    ?>
</body>
</html>