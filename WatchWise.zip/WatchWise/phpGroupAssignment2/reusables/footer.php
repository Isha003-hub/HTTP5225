<footer class="py-4">
    <div class="container text-center">
        <p class="mb-1 footer-text">&copy; 2025 ReviewMyDrama. All rights reserved.</p>
    </div>
</footer>